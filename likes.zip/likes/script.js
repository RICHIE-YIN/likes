function incrementButton1() {
    var element = document.getElementById ('incrementtext1');
    var value = element.innerHTML
    ++value;
    console.log(value);
document.getElementById('incrementtext1').innerHTML = value;
}

function incrementButton2() {
    var element = document.getElementById ('incrementtext2');
    var value = element.innerHTML
    ++value;
    console.log(value);
document.getElementById('incrementtext2').innerHTML = value;
}

function incrementButton3() {
    var element = document.getElementById ('incrementtext3');
    var value = element.innerHTML
    ++value;
    console.log(value);
document.getElementById('incrementtext3').innerHTML = value;
}